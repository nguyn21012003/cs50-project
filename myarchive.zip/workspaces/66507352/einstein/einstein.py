weight = int(input("m: "))

c = 300000000
x = weight*c*c
print(x)
