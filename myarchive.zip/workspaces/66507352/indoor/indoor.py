indoor = input()
x = indoor.lower()
print(x)

