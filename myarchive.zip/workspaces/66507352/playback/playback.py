text = input()
x = text.replace(' ', '...')
print(x)
